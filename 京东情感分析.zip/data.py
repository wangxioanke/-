# 导入requests库(请求和页面抓取)
import requests
# 导入time库(设置抓取Sleep时间)
import time
#  导入random库(生成乱序随机数)
import random
# 导入正则库(从页面代码中提取信息)
import re
import os
import csv
# 导入情感分析库
from snownlp import SnowNLP
# 导入数值计算库(常规计算)
import numpy as np
# 导入科学计算库(拼表及各种分析汇总)
import pandas as pd
# 导入绘制图表库(数据可视化)
import matplotlib.pyplot as plt
# 导入结巴分词(关键词提取)
import jieba.analyse
# 设置请求中头文件的信息
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3732.400 QQBrowser/10.5.3819.400',
            'Accept': '*/*',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
            'Connection': 'close',
            'Referer': 'https://item.jd.com/'
            }

# 设置Cookie的内容
cookie = {
    'unpl': 'V2_ZzNtbRUAQxIgChFQchtVUmJRRVxKVhATJ1tHV3scXAViA0FbclRCFX0URlRnGVoUZwcZXkJcRxVFCEdkeBBVAWMDE1VGZxBFLV0CFSNGF1wjU00zQwBBQHcJFF0uSgwDYgcaDhFTQEJ2XBVQL0oMDDdRFAhyZ0AVRQhHZHgbVARnAhVVQ2dzEkU4dlF%2bGV0EZjMTbUNnAUEpAUBTfx9fSGQBGlxCVkQddDhHZHg%3d',
    '__jdv': '76161171|baidu-pinzhuan|t_288551095_baidupinzhuan|cpc|0f3d30c8dba7459bb52f2eb5eba8ac7d_0_ff16d3f5838f4cf090b7cb02141141b7|1573975311990',
    '__jdu': '239010690',
    'areaId': '6',
    'ipLoc-djd': '6-303-36781-0',
    'PCSYCityID': 'CN_140000_140100_140106',
    'shshshfpb': 'jqH3At%2FfU9SrlFcfQjnfgMw%3D%3D',
    'shshshfpa': 'jqH3At%2FfU9SrlFcfQjnfgMw%3D%3D',
    '__jda': '122270672.239010690.1573975311.1573975311.1573975312.1',
    '__jdc': '122270672',
    '3AB9D23F7A4B3C9B': 'WVUDLUVYFRMFVKWZOXHTGBDYUMV5HMLY2VYDBX3UYJL672OAJ7LWVIW6GONDLMS7TCDWMSZKMYEAZRERTJXKDOILGU',
    'shshshfp': 'd36a43b250efcf39d0b6add590016f0d',
    '__jdb': '122270672.5.239010690|1.1573975312',
    'shshshsID': '26d62b30ea6b57e4d6469f7de971d0bd_5_1573975729111',
    'JSESSIONID': '63E9CE05E36AD715BF1AEEFF241759B5.s1'

}

productIds = [100003150357, 10265477083, 100004751037, 34664250889, 100003052761, 100004917490]
# 设置URL的第一部分
url1 = 'https://sclub.jd.com/comment/productPageComments.action?callback=callback=fetchJSON_comment98vv2511&productId='
# 设置URL的第二部分
url2 = '&score=0&sortType=5&page='
# 设置URL的第三部分
url3 = '&pageSize=10&isShadowSku=0&rid=0&fold=1'
# 乱序输出0-100的唯一随机数
# 随机选取50页评论进行抓取
ran_num = random.sample(range(100), 50)


def jie_xi(url1, productId, url2, ran_num, url3):
    # 拼接URL并乱序循环抓取页面
    for i in ran_num:
        i = str(i)
        url = (url1+productId+url2+i+url3)
        r = requests.get(url=url, headers=headers, cookies=cookie)
        html = r.content   # .content返回的是bytes型也就是二进制的数据
        print("当前抓取页面:", url, "状态:", r)
        html = str(html, encoding="GBK")  # 对抓取的页面进行编码
        # file = open("page.txt", "w")  # 将编码后的页面输出为txt文本存储
        # file.writelines(html)
        # 使用正则提取userClient字段信息
        user_comment = re.findall(r',.*?"content":(.*?),', html)
        # usera = re.findall(r',.*?"creationTime":(.*?),', html)
        # userd = re.findall(r',.*?"referenceName":(.*?),', html)
        write_to_csv(user_comment, productId)
        write_to_txt(user_comment, productId)
        print(user_comment)
        time.sleep(3)


def write_to_csv(content, id):
    file = './数据/评论' + id + '.csv'
    # newline=''确保没有空行
    f = open(file, 'a', encoding='utf-8', newline='')
    writer = csv.writer(f)
    for i in range(len(content)):
        writer.writerow([content[i]])


# 存入txt
def write_to_txt(content, id):
    file = './数据/评论' + id + '.txt'
    # newline=''确保没有空行
    f = open(file, 'a', encoding='utf-8', newline='')
    for i in range(len(content)):
        f.write(content[i])


def run():
    for productId in productIds:
        time.sleep(3)
        productId = str(productId)
        jie_xi(url1, productId, url2, ran_num, url3)
run()
