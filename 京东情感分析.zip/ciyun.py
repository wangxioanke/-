from os import path
from PIL import Image
from wordcloud import WordCloud, ImageColorGenerator
import matplotlib.pyplot as plt
import numpy as np
import jieba
import pandas as pd
# 导入数据
data = pd.read_csv('./数据/评论100004917490.csv')
def GetWordCloud():
    path_txt = './数据/评论100004917490.txt'
    path_img = "test.jpg"
    f = open(path_txt, 'r', encoding='utf-8').read()
    background_image = np.array(Image.open(path_img))
    # join() 方法用于将序列中的元素以指定的字符连接生成一个新的字符串
    cut_text = " ".join(jieba.cut(f))
    # mask参数=图片背景，必须要写上，另外有mask参数再设定宽高是无效的
    wordcloud = WordCloud(font_path="simhei.ttf", background_color="white", mask=background_image).generate(cut_text)
    # 生成颜色值
    image_colors = ImageColorGenerator(background_image)
    # 下面代码表示显示图片
    plt.imshow(wordcloud.recolor(color_func=image_colors), interpolation="bilinear")
    # 获得模块所在的路径的
    d = path.dirname(__file__)
    # os.path.join()：  将多个路径组合后返回
    wordcloud.to_file(path.join(d, "1.png"))
    plt.axis("off")
    plt.show()


GetWordCloud()
